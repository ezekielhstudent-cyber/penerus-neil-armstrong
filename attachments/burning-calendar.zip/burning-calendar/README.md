# Karhutla burning calendar (Kalimantan)

1. Unzip both NASA archives into `data/raw/` (M-C61 and SV-C2, archive + nrt CSVs).
2. `python pipeline/harmonize_hotspots.py --raw data/raw --out data/processed`
3. `python build_frontend.py`          (injects the data into `frontend/index.html`)
4. `uvicorn backend.main:app --reload` (open http://127.0.0.1:8000)

`frontend/index.html` also works on its own by double-clicking it; only the 1 km hotspot CSV button needs the backend.

Known limits: province borders are approximate rectangles-and-lines, not an official boundary file; Aug-Oct 2026 are
near-real-time (no fire-type field); the Aqua/VIIRS ratio is per calendar month, so very quiet years are overestimated.
