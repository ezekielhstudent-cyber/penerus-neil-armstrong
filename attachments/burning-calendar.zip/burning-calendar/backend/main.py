"""
Backend: serves the web app and streams the filtered 1 km hotspot CSV (DuckDB reads the pipeline output directly).

  pip install fastapi uvicorn duckdb
  uvicorn backend.main:app --reload        # then open http://127.0.0.1:8000
"""
import os
from typing import Optional

import duckdb
from fastapi import FastAPI
from fastapi.responses import FileResponse, StreamingResponse

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DAYS = os.environ.get("CELL_DAYS", os.path.join(ROOT, "data", "processed", "cell_days.csv.gz"))
app = FastAPI(title="Karhutla burning calendar")


@app.get("/api/health")
def health():
    return {"ok": os.path.exists(DAYS)}


@app.get("/api/hotspots.csv")
def hotspots(start: str, end: str, lat_min: float = -90, lat_max: float = 90,
             lon_min: float = -180, lon_max: float = 180, prov: Optional[int] = None):
    """1 km hotspot-days (both sensors, vegetation fires, as detected) for a province or box and a date range."""
    sql = ("SELECT date, sensor, lat, lon, prov, frp FROM read_csv_auto(?) "
           "WHERE date BETWEEN ?::DATE AND ?::DATE AND lat BETWEEN ? AND ? AND lon BETWEEN ? AND ?")
    params = [DAYS, start, end, lat_min, lat_max, lon_min, lon_max]
    if prov:
        sql += " AND prov = ?"
        params.append(prov)

    def rows():
        cur = duckdb.connect().execute(sql + " ORDER BY date, sensor", params)
        yield "date,sensor,lat,lon,prov,frp\n"
        while True:
            chunk = cur.fetchmany(50_000)
            if not chunk:
                break
            yield "".join(",".join("" if v is None else str(v) for v in r) + "\n" for r in chunk)

    return StreamingResponse(rows(), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="hotspots_1km.csv"'})


@app.get("/")
def index():
    return FileResponse(os.path.join(ROOT, "frontend", "index.html"))
