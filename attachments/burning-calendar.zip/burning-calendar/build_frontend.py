"""Inject data/processed/app_data.json into frontend/template.html -> frontend/index.html (self-contained)."""
import pathlib
root = pathlib.Path(__file__).parent
html = (root / "frontend/template.html").read_text(encoding="utf-8")
data = (root / "data/processed/app_data.json").read_text(encoding="utf-8")
(root / "frontend/index.html").write_text(html.replace("__DATA__", data), encoding="utf-8")
print("wrote frontend/index.html")
