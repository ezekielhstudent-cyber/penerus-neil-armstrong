"""
Harmonize MODIS Aqua (M-C61) and VIIRS S-NPP (SV-C2) hotspots for Kalimantan.

  python pipeline/harmonize_hotspots.py --raw data/raw --out data/processed

Reads  : fire_archive_* and fire_nrt_* CSVs of both products (unzipped in --raw)
Writes : app_data.json    monthly counts per 0.25-degree block x province, validation, metadata
         cell_days.csv.gz 1 km (0.01 deg) hotspot-days used for the hotspot CSV download
Needs  : pandas, numpy only
"""
import argparse, glob, json, os
import numpy as np
import pandas as pd

G, BLK, UTC_H = 0.01, 0.25, 7.5                    # 1 km grid, analysis block, local-time shift (WIB/WITA midpoint)
Y0, END = 2002, pd.Timestamp("2026-10-01")          # last complete month of the supplied data
VS, OV_END = pd.Timestamp("2012-02-01"), pd.Timestamp("2020-12-01")   # first full VIIRS month; end of stable Aqua overlap
PROV = {1: "West Kalimantan", 2: "Central Kalimantan", 3: "South Kalimantan", 4: "East Kalimantan", 5: "North Kalimantan"}
# Approximate outline of Indonesian Kalimantan (lon, lat). Replace with an official boundary file for production.
POLY = [(109.6,1.9),(110.5,1.5),(111,1.1),(112.2,1.4),(114,1.3),(114.8,2.2),(115.5,3.5),(116.2,4.4),(117.4,4.4),(117.9,4.2),
        (118.1,3.8),(117.6,2),(118.1,1),(117.6,0),(117.2,-1),(116.6,-1.9),(116.2,-3.2),(115.4,-3.9),(114.6,-4.1),(113.6,-3.5),
        (112.5,-3.5),(111.7,-3.3),(110.3,-3.1),(110.1,-2),(109.9,-1),(109.2,-.2),(108.9,.8),(108.9,1.8)]


def inside(x, y):
    c = np.zeros(len(x), bool)
    for k in range(len(POLY)):
        (x1, y1), (x2, y2) = POLY[k], POLY[(k + 1) % len(POLY)]
        c ^= ((y1 > y) != (y2 > y)) & (x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1)
    return c


def province(lon, lat):   # approximate division, same rule as the web map
    return np.select([(lat >= 2.0) & (lon >= 114.2), (lon >= 114.6) & (lat >= -1.9), lon >= 114.6,
                      (lon < 111.2) | (lat >= 0.2)], [5, 4, 3, 1], default=2)


def read(raw, product, sensor):
    """Clean one sensor: vegetation fires only, confident detections, one hotspot per 1 km cell per local day."""
    parts = [pd.read_csv(f, usecols=lambda c: c in {"latitude", "longitude", "acq_date", "acq_time", "satellite", "confidence", "type", "frp"})
             for f in sorted(glob.glob(f"{raw}/fire_*_{product}_*.csv"))]
    d = pd.concat(parts, ignore_index=True)
    d = d[d["latitude"].between(-4.6, 4.6) & d["longitude"].between(108.5, 119.0)]
    if "type" in d:
        d = d[d["type"].isna() | (d["type"] == 0)]       # type is absent in NRT files; 0 = vegetation fire
    if sensor == "aqua":
        d = d[(d["satellite"] == "Aqua") & (pd.to_numeric(d["confidence"], errors="coerce") >= 50)]
    else:
        d = d[d["confidence"].astype(str).isin(["n", "h"])]
    hhmm = d["acq_time"].astype(int)
    ts = pd.to_datetime(d["acq_date"]) + pd.to_timedelta(hhmm // 100 * 60 + hhmm % 100, unit="m") + pd.Timedelta(hours=UTC_H)
    d = d.assign(date=ts.dt.floor("D"), gi=np.floor(d["latitude"] / G).astype(np.int32), gj=np.floor(d["longitude"] / G).astype(np.int32))
    out = d.groupby(["date", "gi", "gj"], as_index=False).agg(frp=("frp", "max"))
    print(f"{sensor}: {len(d):,} detections -> {len(out):,} 1 km cell-days")
    return out.assign(sensor=sensor)


def fit(A, V, T, mask):
    """MODIS-Aqua / VIIRS ratio per calendar month over the months in mask."""
    return np.array([A[:, mask & (T % 12 == m)].sum() / max(V[:, mask & (T % 12 == m)].sum(), 1) for m in range(12)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw")
    ap.add_argument("--out", default="data/processed")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    cd = pd.concat([read(a.raw, "M-C61", "aqua"), read(a.raw, "SV-C2", "viirs")], ignore_index=True)
    u = cd[["gi", "gj"]].drop_duplicates().reset_index(drop=True)          # clip to Kalimantan on unique 1 km cells
    lon, lat = (u["gj"] + .5) * G, (u["gi"] + .5) * G
    u = u[inside(lon.values, lat.values)].assign(lat=lat, lon=lon)
    u["prov"] = province(u["lon"].values, u["lat"].values)
    u["bi"], u["bj"] = np.floor(u["lat"] / BLK).astype(int), np.floor(u["lon"] / BLK).astype(int)
    cd = cd.merge(u, on=["gi", "gj"])
    print(f"inside Kalimantan: {len(cd):,} cell-days")
    cd[["date", "sensor", "lat", "lon", "prov", "frp"]].round(4).to_csv(f"{a.out}/cell_days.csv.gz", index=False)

    # monthly counts per block x province x sensor
    ms = pd.date_range(f"{Y0}-01-01", END, freq="MS"); NT = len(ms)
    cd["t"] = (cd["date"].dt.year - Y0) * 12 + cd["date"].dt.month - 1
    cd = cd[(cd["t"] >= 0) & (cd["t"] < NT)]
    keys = cd[["bi", "bj", "prov"]].drop_duplicates().sort_values(["prov", "bi", "bj"]).reset_index(drop=True)
    keys["k"] = keys.index
    cd = cd.merge(keys, on=["bi", "bj", "prov"])
    arr = {s: np.zeros((len(keys), NT)) for s in ("aqua", "viirs")}
    for s, g in cd.groupby("sensor"):
        c = g.groupby(["k", "t"]).size()
        arr[s][c.index.get_level_values(0), c.index.get_level_values(1)] = c.values
    A, V = arr["aqua"], arr["viirs"]
    T = np.arange(NT)
    tvs, tov = (VS.year - Y0) * 12 + VS.month - 1, (OV_END.year - Y0) * 12 + OV_END.month - 1
    d0 = cd.loc[cd["sensor"] == "aqua", "date"].min()
    t0 = (d0.year - Y0) * 12 + d0.month - 1 + (0 if d0.day == 1 else 1)     # first full Aqua month
    print("first Aqua day", d0.date(), "-> first full month", ms[t0].date())

    ov = (T >= tvs) & (T <= tov)
    R = fit(A, V, T, ov)
    H = np.where(T < tvs, A, V * R[T % 12]); H[:, :t0] = 0
    RAW = np.where(T < tvs, A, V); RAW[:, :t0] = 0

    # leave-one-year-out validation at province x month level
    P = [keys.loc[keys["prov"] == p, "k"].values for p in PROV]
    sumP = lambda X: np.array([X[idx].sum(axis=0) for idx in P])          # province x month
    Ap, Vp = sumP(A), sumP(V)
    rows = []
    for y in range(2012, 2021):
        mask = ov & ((T // 12 + Y0) != y)
        r = fit(A, V, T, mask)
        ts = [t for t in range(tvs, tov + 1) if t // 12 + Y0 == y]
        obs, vv = Ap[:, ts], Vp[:, ts]
        pred = vv * r[np.array(ts) % 12]
        rows.append(dict(y=y, raw=100 * (vv.sum() - obs.sum()) / obs.sum(), h=100 * (pred.sum() - obs.sum()) / obs.sum(),
                         r=float(np.corrcoef(pred.ravel(), obs.ravel())[0, 1]), obs=int(obs.sum())))
    val = dict(rows=rows, mean=dict(raw=float(np.mean([abs(x["raw"]) for x in rows])), h=float(np.mean([abs(x["h"]) for x in rows])),
                                    r=float(np.mean([x["r"] for x in rows]))))
    print(pd.DataFrame(rows).round(2).to_string(index=False)); print("ratios", R.round(3))

    cells = [dict(la=float((r.bi + .5) * BLK), lo=float((r.bj + .5) * BLK), p=int(r.prov),
                  h=[int(round(v)) for v in H[r.k]], r=[int(v) for v in RAW[r.k]]) for r in keys.itertuples()]
    cells = [c for c in cells if sum(c["h"]) > 0]
    meta = dict(y0=Y0, nt=NT, t0=int(t0), vs=int(tvs), ov_end=int(tov), ratios=[float(x) for x in R], utc_shift=UTC_H,
                last_month=str(ms[-1].date()), prov={str(k): v for k, v in PROV.items()})
    json.dump(dict(meta=meta, validation=val, cells=cells), open(f"{a.out}/app_data.json", "w"), separators=(",", ":"))
    print("cells:", len(cells), "json MB:", round(os.path.getsize(f"{a.out}/app_data.json") / 1e6, 2))


if __name__ == "__main__":
    main()
