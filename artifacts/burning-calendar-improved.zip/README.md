# Karhutla burning calendar (Kalimantan)

Harmonized MODIS Aqua + VIIRS S-NPP active-fire hotspots for Indonesian Kalimantan, 2002–2026.

## Run

1. Unzip both NASA archives into a folder (M-C61 and SV-C2, archive + nrt CSVs).
2. `python pipeline/harmonize_hotspots.py --raw /path/to/raw --out data/processed`
3. `python build_frontend.py`          (injects data into `frontend/index.html`)
4. `uvicorn backend.main:app --reload` (open http://127.0.0.1:8000)

`frontend/index.html` also works on its own by double-clicking it; only the 1 km hotspot CSV button needs the backend.

## What improved

- **Intensity-dependent ratios**: three conversion factors (low / mid / high VIIRS activity terciles) per calendar month. Quiet years are no longer systematically overestimated by the high-fire ratio.
- Validation (leave-one-year-out 2012–2020): mean absolute bias ~11 %, correlation ~0.97.
- Clearer notes in the UI about remaining limits.

## Known limits

- Province borders are approximate rectangles / rules, not an official boundary file. Swap one in for anything operational.
- Aug–Oct 2026 come from the near-real-time files, which have no fire-type field, so industrial heat sources aren’t fully removed there. Nov 2026 is dropped because VIIRS only runs to early November in the supplied data.
- Early calendar months: Aqua’s first full month is Aug 2002, so Jan–Jul 2002 are blank.
- Extremely quiet years (e.g. 2020) can still be overestimated; the intensity bins help but do not eliminate the problem completely.
