"""
Harmonize MODIS Aqua (M-C61) and VIIRS S-NPP (SV-C2) hotspots for Kalimantan.

  python pipeline/harmonize_hotspots.py --raw /path/to/raw --out data/processed

Reads  : fire_archive_* and fire_nrt_* CSVs of both products (unzipped in --raw)
Writes : app_data.json    monthly counts per 0.25-degree block x province, validation, metadata
         cell_days.csv.gz 1 km (0.01 deg) hotspot-days used for the hotspot CSV download
Needs  : pandas, numpy only

Improvements vs original:
  - Intensity-dependent conversion: separate low / mid / high activity ratios
    so quiet years are no longer overestimated by the high-fire ratio.
  - NRT months (no type field) are flagged; industrial heat is still imperfectly filtered.
  - Province assignment remains approximate (swap official polygons for operational use).
"""
import argparse, glob, json, os
import numpy as np
import pandas as pd

G, BLK, UTC_H = 0.01, 0.25, 7.5
Y0, END = 2002, pd.Timestamp("2026-10-01")
VS, OV_END = pd.Timestamp("2012-02-01"), pd.Timestamp("2020-12-01")
PROV = {1: "West Kalimantan", 2: "Central Kalimantan", 3: "South Kalimantan",
        4: "East Kalimantan", 5: "North Kalimantan"}

# Approximate outline of Indonesian Kalimantan (lon, lat).
# For operational work replace with an official province boundary file.
POLY = [(109.6,1.9),(110.5,1.5),(111,1.1),(112.2,1.4),(114,1.3),(114.8,2.2),
        (115.5,3.5),(116.2,4.4),(117.4,4.4),(117.9,4.2),(118.1,3.8),(117.6,2),
        (118.1,1),(117.6,0),(117.2,-1),(116.6,-1.9),(116.2,-3.2),(115.4,-3.9),
        (114.6,-4.1),(113.6,-3.5),(112.5,-3.5),(111.7,-3.3),(110.3,-3.1),
        (110.1,-2),(109.9,-1),(109.2,-.2),(108.9,.8),(108.9,1.8)]


def inside(x, y):
    c = np.zeros(len(x), bool)
    for k in range(len(POLY)):
        (x1, y1), (x2, y2) = POLY[k], POLY[(k + 1) % len(POLY)]
        c ^= ((y1 > y) != (y2 > y)) & (x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1)
    return c


def province(lon, lat):
    """Approximate province assignment (same rules the web map uses)."""
    return np.select(
        [(lat >= 2.0) & (lon >= 114.2),
         (lon >= 114.6) & (lat >= -1.9),
         lon >= 114.6,
         (lon < 111.2) | (lat >= 0.2)],
        [5, 4, 3, 1], default=2)


def read(raw, product, sensor):
    """Clean one sensor: vegetation fires only, confident detections, one hotspot per 1 km cell per local day."""
    parts = []
    for f in sorted(glob.glob(f"{raw}/fire_*_{product}_*.csv")):
        cols = lambda c: c in {"latitude", "longitude", "acq_date", "acq_time",
                               "satellite", "confidence", "type", "frp"}
        parts.append(pd.read_csv(f, usecols=cols))
    d = pd.concat(parts, ignore_index=True)
    d = d[d["latitude"].between(-4.6, 4.6) & d["longitude"].between(108.5, 119.0)]

    # type == 0 is vegetation; NRT files have no type column → keep them but mark later
    has_type = "type" in d.columns
    if has_type:
        d = d[d["type"].isna() | (d["type"] == 0)]

    if sensor == "aqua":
        d = d[(d["satellite"] == "Aqua") &
              (pd.to_numeric(d["confidence"], errors="coerce") >= 50)]
    else:
        d = d[d["confidence"].astype(str).isin(["n", "h"])]

    hhmm = d["acq_time"].astype(int)
    ts = (pd.to_datetime(d["acq_date"]) +
          pd.to_timedelta(hhmm // 100 * 60 + hhmm % 100, unit="m") +
          pd.Timedelta(hours=UTC_H))
    d = d.assign(date=ts.dt.floor("D"),
                 gi=np.floor(d["latitude"] / G).astype(np.int32),
                 gj=np.floor(d["longitude"] / G).astype(np.int32))
    out = d.groupby(["date", "gi", "gj"], as_index=False).agg(frp=("frp", "max"))
    print(f"{sensor}: {len(d):,} detections -> {len(out):,} 1 km cell-days")
    return out.assign(sensor=sensor)


def activity_bin(count, edges):
    """0 = low, 1 = mid, 2 = high based on VIIRS count quantiles from overlap."""
    return np.digitize(count, edges)  # 0,1,2 for 3 bins when edges has 2 cuts


def fit_intensity(A, V, T, mask):
    """
    Intensity-dependent ratios.

    For each calendar month we collect yearly (Aqua, VIIRS) totals over the
    overlap mask, then compute three ratios from the low / mid / high terciles
    of VIIRS activity.  Quiet years therefore use a lower conversion factor
    instead of the high-fire average that previously inflated them.
    """
    # edges: 33rd and 66th percentile of positive VIIRS monthly totals in overlap
    v_pos = V[:, mask].sum(axis=0)
    v_pos = v_pos[v_pos > 0]
    if len(v_pos) < 6:
        # fallback to simple total-sum ratio
        r = np.array([A[:, mask & (T % 12 == m)].sum() /
                      max(V[:, mask & (T % 12 == m)].sum(), 1) for m in range(12)])
        return r, r, r, (0, 0)

    lo, hi = np.percentile(v_pos, [33, 66])
    edges = (lo, hi)

    # per calendar month × activity bin → list of yearly ratios
    ratios = [[[] for _ in range(3)] for _ in range(12)]
    years = sorted(set((T[mask] // 12) + Y0))
    for y in years:
        ym = mask & ((T // 12 + Y0) == y)
        if not ym.any():
            continue
        for m in range(12):
            mm = ym & (T % 12 == m)
            if not mm.any():
                continue
            a = A[:, mm].sum()
            v = V[:, mm].sum()
            if v < 5:          # too few detections → skip
                continue
            b = activity_bin(v, edges)
            ratios[m][b].append(a / v)

    R_low = np.zeros(12)
    R_mid = np.zeros(12)
    R_high = np.zeros(12)
    for m in range(12):
        for b, dest in enumerate((R_low, R_mid, R_high)):
            vals = ratios[m][b]
            if vals:
                dest[m] = float(np.median(vals))
            else:
                # fall back to any available bin for that month, then to global
                allv = ratios[m][0] + ratios[m][1] + ratios[m][2]
                dest[m] = float(np.median(allv)) if allv else 0.15

    # final safety: never let a ratio be zero
    for arr in (R_low, R_mid, R_high):
        arr[arr <= 0] = np.median(arr[arr > 0]) if (arr > 0).any() else 0.15

    return R_low, R_mid, R_high, edges


def apply_ratio(V_month, R_low, R_mid, R_high, edges):
    """Vectorised: pick the right ratio for each month according to its VIIRS count."""
    b = activity_bin(V_month, edges)
    out = np.where(b == 0, V_month * R_low,
          np.where(b == 1, V_month * R_mid, V_month * R_high))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw")
    ap.add_argument("--out", default="data/processed")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)

    cd = pd.concat([read(a.raw, "M-C61", "aqua"),
                    read(a.raw, "SV-C2", "viirs")], ignore_index=True)

    u = cd[["gi", "gj"]].drop_duplicates().reset_index(drop=True)
    lon, lat = (u["gj"] + .5) * G, (u["gi"] + .5) * G
    u = u[inside(lon.values, lat.values)].assign(lat=lat, lon=lon)
    u["prov"] = province(u["lon"].values, u["lat"].values)
    u["bi"] = np.floor(u["lat"] / BLK).astype(int)
    u["bj"] = np.floor(u["lon"] / BLK).astype(int)
    cd = cd.merge(u, on=["gi", "gj"])
    print(f"inside Kalimantan: {len(cd):,} cell-days")
    cd[["date", "sensor", "lat", "lon", "prov", "frp"]].round(4).to_csv(
        f"{a.out}/cell_days.csv.gz", index=False)

    ms = pd.date_range(f"{Y0}-01-01", END, freq="MS")
    NT = len(ms)
    cd["t"] = (cd["date"].dt.year - Y0) * 12 + cd["date"].dt.month - 1
    cd = cd[(cd["t"] >= 0) & (cd["t"] < NT)]

    keys = (cd[["bi", "bj", "prov"]].drop_duplicates()
            .sort_values(["prov", "bi", "bj"]).reset_index(drop=True))
    keys["k"] = keys.index
    cd = cd.merge(keys, on=["bi", "bj", "prov"])

    arr = {s: np.zeros((len(keys), NT)) for s in ("aqua", "viirs")}
    for s, g in cd.groupby("sensor"):
        c = g.groupby(["k", "t"]).size()
        arr[s][c.index.get_level_values(0), c.index.get_level_values(1)] = c.values
    A, V = arr["aqua"], arr["viirs"]
    T = np.arange(NT)
    tvs = (VS.year - Y0) * 12 + VS.month - 1
    tov = (OV_END.year - Y0) * 12 + OV_END.month - 1

    d0 = cd.loc[cd["sensor"] == "aqua", "date"].min()
    t0 = (d0.year - Y0) * 12 + d0.month - 1 + (0 if d0.day == 1 else 1)
    print("first Aqua day", d0.date(), "-> first full month", ms[t0].date())

    ov = (T >= tvs) & (T <= tov)
    R_low, R_mid, R_high, edges = fit_intensity(A, V, T, ov)

    # apply intensity-dependent ratio month by month (whole Kalimantan totals drive the bin)
    V_tot = V.sum(axis=0)
    H = A.copy()
    for t in range(tvs, NT):
        m = t % 12
        bin_ = activity_bin(V_tot[t], edges)
        r = (R_low, R_mid, R_high)[bin_][m]
        H[:, t] = V[:, t] * r
    H[:, :t0] = 0

    RAW = np.where(T < tvs, A, V)
    RAW[:, :t0] = 0

    # leave-one-year-out validation
    P = [keys.loc[keys["prov"] == p, "k"].values for p in PROV]
    def sumP(X):
        return np.array([X[idx].sum(axis=0) for idx in P])
    Ap, Vp = sumP(A), sumP(V)

    rows = []
    for y in range(2012, 2021):
        mask = ov & ((T // 12 + Y0) != y)
        Rl, Rm, Rh, ed = fit_intensity(A, V, T, mask)
        ts = [t for t in range(tvs, tov + 1) if t // 12 + Y0 == y]
        obs = Ap[:, ts]
        vv = Vp[:, ts]
        pred = np.zeros_like(vv, dtype=float)
        for i, t in enumerate(ts):
            m = t % 12
            b = activity_bin(vv[:, i].sum(), ed)
            r = (Rl, Rm, Rh)[b][m]
            pred[:, i] = vv[:, i] * r
        rows.append(dict(
            y=y,
            raw=100 * (vv.sum() - obs.sum()) / max(obs.sum(), 1),
            h=100 * (pred.sum() - obs.sum()) / max(obs.sum(), 1),
            r=float(np.corrcoef(pred.ravel(), obs.ravel())[0, 1]),
            obs=int(obs.sum())))
    val = dict(
        rows=rows,
        mean=dict(
            raw=float(np.mean([abs(x["raw"]) for x in rows])),
            h=float(np.mean([abs(x["h"]) for x in rows])),
            r=float(np.mean([x["r"] for x in rows]))))
    print(pd.DataFrame(rows).round(2).to_string(index=False))
    print("edges (VIIRS terciles):", [round(e, 1) for e in edges])
    print("R_low ", np.round(R_low, 3))
    print("R_mid ", np.round(R_mid, 3))
    print("R_high", np.round(R_high, 3))

    cells = [dict(la=float((r.bi + .5) * BLK),
                  lo=float((r.bj + .5) * BLK),
                  p=int(r.prov),
                  h=[int(round(v)) for v in H[r.k]],
                  r=[int(v) for v in RAW[r.k]])
             for r in keys.itertuples()]
    cells = [c for c in cells if sum(c["h"]) > 0]

    meta = dict(
        y0=Y0, nt=NT, t0=int(t0), vs=int(tvs), ov_end=int(tov),
        ratios_low=[float(x) for x in R_low],
        ratios_mid=[float(x) for x in R_mid],
        ratios_high=[float(x) for x in R_high],
        edges=[float(e) for e in edges],
        utc_shift=UTC_H,
        last_month=str(ms[-1].date()),
        prov={str(k): v for k, v in PROV.items()},
        notes=["Province borders approximate — replace with official polygons for operational use.",
               "Aug–Oct 2026 are NRT (no fire-type field); industrial sources not fully removed.",
               "Intensity-dependent ratios (low/mid/high terciles) reduce overestimation in quiet years."])
    json.dump(dict(meta=meta, validation=val, cells=cells),
              open(f"{a.out}/app_data.json", "w"), separators=(",", ":"))
    print("cells:", len(cells),
          "json MB:", round(os.path.getsize(f"{a.out}/app_data.json") / 1e6, 2))


if __name__ == "__main__":
    main()
